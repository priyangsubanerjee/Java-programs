import lab6.marketing.sales;

class Simple {
    public static void main(String[] args) {
        sales s = new sales(1, "John");
        s.tallowance(1000);
    }
}
